/**
 * @file src/app/App.tsx
 *
 * FIX L-2: ErrorBoundary wraps the entire app so render/effect crashes
 *           show a user-visible error rather than a blank screen.
 * FIX C-1: env validation is now shown as a UI error instead of crashing
 *           before React renders.
 */
import { Component, type ReactNode } from 'react';
import { GlobalModals } from '@/components/ui/GlobalModals';
import { DropMap } from '@/components/map/DropMap';
import { validateEnv } from '@/lib/env';

// ── ErrorBoundary ─────────────────────────────────────────────────────────────
interface EBState { hasError: boolean; message: string }
class ErrorBoundary extends Component<{ children: ReactNode }, EBState> {
  state: EBState = { hasError: false, message: '' };
  static getDerivedStateFromError(err: Error): EBState {
    return { hasError: true, message: err.message };
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 flex items-center justify-center p-8">
          <div className="max-w-md w-full bg-red-950 border border-red-700 rounded-2xl p-6 text-center">
            <h2 className="text-xl font-bold text-red-300 mb-2">Application Error</h2>
            <p className="text-red-400 text-sm font-mono">{this.state.message}</p>
            <button
              onClick={() => window.location.reload()}
              className="mt-4 px-4 py-2 rounded-xl bg-red-700 text-white text-sm hover:bg-red-600"
            >
              Reload
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// ── Env Check ─────────────────────────────────────────────────────────────────
function MissingEnvBanner({ missing }: { missing: string[] }) {
  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-8">
      <div className="max-w-md w-full bg-amber-950 border border-amber-700 rounded-2xl p-6">
        <h2 className="text-xl font-bold text-amber-300 mb-2">Missing Configuration</h2>
        <p className="text-amber-400 text-sm mb-3">
          The following required environment variables are not set. Create a{' '}
          <code className="bg-amber-900 px-1 rounded">.env.local</code> file and add:
        </p>
        <ul className="list-disc list-inside text-amber-300 text-sm font-mono space-y-1">
          {missing.map((k) => <li key={k}>{k}=YOUR_VALUE</li>)}
        </ul>
      </div>
    </div>
  );
}

// ── App Root ──────────────────────────────────────────────────────────────────
const { ok, missing } = validateEnv();

export default function App() {
  if (!ok) {
    return <MissingEnvBanner missing={missing} />;
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-card text-slate-900 dark:text-slate-100 flex flex-col font-sans p-4 md:p-8">
        <header className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight mb-1 text-primary">DropPin Ops</h1>
          <p className="text-muted text-sm max-w-sm">
            Mamburao Live Tracking Unit · Offline Ready
          </p>
        </header>

        <main className="flex-1 w-full max-w-6xl mx-auto flex flex-col">
          <DropMap height="min(75vh, 800px)" />
        </main>

        <GlobalModals />
      </div>
    </ErrorBoundary>
  );
}
