import { validateEnv } from '@/lib/env';

function MissingEnvBanner({ missing }: { missing: string[] }) {
  return (
    <div className='min-h-screen bg-slate-950 flex items-center justify-center p-8'>
      <div className='max-w-md w-full bg-amber-950 border border-amber-700 rounded-2xl p-6'>
        <h2 className='text-xl font-bold text-amber-300 mb-2'>Missing Configuration</h2>
        <ul className='list-disc list-inside text-amber-300 text-sm font-mono space-y-1'>
          {missing.map((k) => <li key={k}>{k}=YOUR_VALUE</li>)}
        </ul>
      </div>
    </div>
  );
}

export function EnvGuard({ children }: { children: React.ReactNode }) {
  const { ok, missing } = validateEnv();

  if (!ok) {
    return <MissingEnvBanner missing={missing} />;
  }

  return <>{children}</>;
}
