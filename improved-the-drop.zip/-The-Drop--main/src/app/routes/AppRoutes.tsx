import { useProfile } from '@/hooks/useProfile';
import { useAuthStore } from '@/stores';
import { AuthPage } from '@/features/auth/AuthPage';
import { SuperAdminPortal } from '@/features/portals/SuperAdminPortal';
import { AdminPortal } from '@/features/portals/AdminPortal';
import { ClientPortal } from '@/features/portals/ClientPortal';

export function AppRoutes() {
  const { profile, loading, isSuperAdmin, isAdmin } = useProfile();
  const { session } = useAuthStore();

  if (loading) {
    return (
      <div className='min-h-screen bg-slate-950 flex items-center justify-center text-emerald-400'>
        Loading platform...
      </div>
    );
  }

  if (!session || !profile) {
    return <AuthPage />;
  }

  if (isSuperAdmin) return <SuperAdminPortal />;
  if (isAdmin) return <AdminPortal />;

  return <ClientPortal />;
}
