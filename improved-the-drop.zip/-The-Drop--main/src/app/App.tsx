import { ErrorBoundary } from '@/app/providers/ErrorBoundary';
import { EnvGuard } from '@/app/providers/EnvGuard';
import { AppRoutes } from '@/app/routes/AppRoutes';
import { GlobalModals } from '@/components/ui/GlobalModals';

export default function App() {
  return (
    <ErrorBoundary>
      <EnvGuard>
        <AppRoutes />
        <GlobalModals />
      </EnvGuard>
    </ErrorBoundary>
  );
}
