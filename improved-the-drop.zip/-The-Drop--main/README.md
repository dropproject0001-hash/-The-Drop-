# The Drop

A multi-role logistics and operations platform with live drop tracking, QR verification, admin portals, and offline map support.

## Features

- Multi-role authentication system
- Admin and Super Admin portals
- Live drop deployment system
- Offline map downloader
- QR confirmation workflows
- Transaction history management
- Firebase + Supabase integrations
- Zustand global state management

## Tech Stack

- React
- Vite
- Tailwind CSS
- Firebase
- Supabase
- Zustand
- React Query
- Leaflet

## Architecture

src/
├── app/
├── components/
├── features/
├── hooks/
├── lib/
├── services/
├── stores/
├── tests/
└── types/

## Setup

```bash
npm install
npm run dev
```

## Environment Variables

Copy `.env.example` into `.env.local`.

## Testing

```bash
npm run test
```

## Roadmap

- Add Playwright e2e tests
- Add CI/CD workflows
- Introduce backend abstraction layer
- Separate Firebase and Supabase responsibilities
- Add analytics dashboard
