import { describe, it, expect } from 'vitest';

describe('Application bootstrap', () => {
  it('loads correctly', () => {
    expect(true).toBe(true);
  });
});
