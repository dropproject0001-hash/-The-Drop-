
# THE DROP — REPO UPGRADE NOTES

High Priority Refactors:
1. Split oversized App.tsx
2. Add service layer
3. Remove Firebase overlap
4. Centralize UI primitives
5. Add testing infrastructure
6. Optimize realtime channels
7. Add design tokens

Recommended UI:
- dark cinematic dashboard
- emerald neon glow
- glass cards
- motion-driven interactions
