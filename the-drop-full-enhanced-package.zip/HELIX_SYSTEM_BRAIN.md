
# THE DROP — HELIX SYSTEM BRAIN v2.0

Purpose:
Production-grade AI coding operating system for THE DROP platform.

Core Stack:
- React 18
- TypeScript strict
- Vite
- Tailwind CSS
- shadcn/ui
- Framer Motion
- Zustand
- TanStack Query
- Supabase
- Leaflet

Core Rules:
1. Supabase-first architecture
2. No backend calls inside UI components
3. No god components
4. Strict TypeScript only
5. Centralized design system
6. Realtime cleanup mandatory
7. Service-layer architecture
8. Premium cinematic UI consistency

Recommended Structure:
src/
├── app/
├── components/
├── features/
├── hooks/
├── services/
├── stores/
├── providers/
├── routes/
├── styles/
└── types/

UI Direction:
- emerald cyber luxury
- glassmorphism
- cinematic gradients
- smooth motion
- premium spacing
- reusable primitives
